# AndroidSlices
Android slices examples. Slices allow your app content containing static and dynamic data, input controls and action items to be displayed in another app.

For detailed explanation of slices and examples, see http://www.zoftino.com/android-slices-with-examples
